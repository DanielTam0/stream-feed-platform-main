from flask import Flask, render_template, url_for, request
from summa import keywords


app = Flask(__name__)
@app.route('/')
@app.route('/home')
def home():
    return render_template("index.html")


@app.route('/result', methods=['POST', 'GET'])
def result():
    output = request.form.to_dict()
    text = output["paper"]
    TR_keywords = keywords.keywords(text, scores=True)
    
    return render_template('index.html', 
                           kw1 = TR_keywords[0][0], sc1=TR_keywords[0][1],
                           kw2 = TR_keywords[1][0], sc2=TR_keywords[1][1],
                           kw3 = TR_keywords[2][0], sc3=TR_keywords[2][1],
                           kw4 = TR_keywords[3][0], sc4=TR_keywords[3][1],
                           kw5 = TR_keywords[4][0], sc5=TR_keywords[4][1]                          
                           )

if __name__ =="__main__":
    app.run(debug=True)